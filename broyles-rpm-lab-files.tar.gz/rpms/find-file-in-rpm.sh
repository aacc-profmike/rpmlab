#!/bin/bash

# BASH script to help find what local RPM contains a certain file
#
# NOTE: MUST be ran in the same directory along side RPM file
read -p "Name of file needed: " filetofind

for myfile in `ls *.rpm`
do
   if [[ `rpm -qlp $myfile | grep -i $filetofind` ]];
     then echo \"$filetofind\" has been found in $myfile
   fi
done

